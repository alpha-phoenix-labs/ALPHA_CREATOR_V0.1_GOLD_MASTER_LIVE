"""ALPHA CREATOR backend tests."""

